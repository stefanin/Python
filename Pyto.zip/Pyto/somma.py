x = int(input("Inserisci primo val "))
y  = int(input("Inserisci secondo val "))

sum = x + y

if sum > 100:
    print("Numero troppo grande")
else:
    print("la somma è " + str(sum))