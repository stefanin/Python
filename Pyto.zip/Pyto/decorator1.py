def mio_decoratore(funzione_da_decorare):
    def wrapper():
        print("Sono dentro la funzione wrapper e posso accedere " \
            "alla funzione %s" % funzione_da_decorare.__name__)
        return funzione_da_decorare()
    
    return wrapper

@mio_decoratore
def foo():
    print("Io sono la funzione da decorare")

print(foo())
