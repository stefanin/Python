import http.client
import json 

class Service(object):
    conn = None
    
    def __init__(self):
        self.conn = http.client.HTTPConnection("letus.vfdns.org")
    
    def listLogFile(self):
        self.conn.request(method = "GET", url = "/java/teatro/spettacoli.json")
        res = self.conn.getresponse()
        jsonStr = str(res.read().decode("utf-8"))

        data = json.loads(jsonStr)

        self.conn.close()

        return data

try:
    s = Service()
    data = s.listLogFile()
    print(data[0]["descrizione"])

    #for i in data:
    #print (data["nometeatro"])
    #print (data["email"])

except json.JSONDecodeError as jerr:
    print(jerr)