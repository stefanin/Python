def opzioni(nome):
    def mio_decoratore(funzione_da_decorare):
        def wrapper(*args, **kwargs):
            kwargs.update({'nome': nome})
            print("Chiamo la funzione %s" % funzione_da_decorare)
            return funzione_da_decorare(*args, **kwargs)
        return wrapper
    return mio_decoratore

@opzioni("pinco")
def stampa_nome(nome = None):
    print("Ciao ", nome)

#stampa_nome()
stampa_nome(nome = "Antonio")