import sqlite3 as sq

class Conn:
    conn = None
    
    def __init__(self):
        self.conn = sq.connect('./films.sqlite')
    
    def getAll(self):
        with self.conn:
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM film")
            rows = cursor.fetchall()
            for row in rows:
                print("%s - %s" % (row[0], row[1]))
                
if __name__ == "__main__":
    c = Conn()
    c.getInfos()

#insert into film values(100, "Titolo 1", "Descrizione del film");