def media(*l):
    sum = 0
    tot = len(l)
    for i in l:
        sum += i
    mediaNum = sum/tot
    return mediaNum

print("media:", str(media(10, 30, 40, 4, 50, 60)))