a, b = 5, 0
try:
    print("Operazione 1")
    print("Operazione 2")
    
    if b == 0:
        raise ZeroDivisionError
    else:
        print(a/b)
    print("Operazione 3")
except ZeroDivisionError as z:
    print("non hai studiato matematica!")
except:
    print('Non e stata effettuata la divisione per zero')
    

else:
    print("Sono dentro il blocco else del try")

finally:
    print("Sono dentro il blocco finally del try")



print("Ciao ")