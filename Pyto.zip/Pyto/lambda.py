areaQuad = lambda base, altezza: base*altezza

print(areaQuad(5, 3))
