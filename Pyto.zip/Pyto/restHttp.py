import urllib.request
response = urllib.request.urlopen('http://python.org/')
html = response.read()

print(html)

import urllib.parse
import urllib.request

url = 'http://www.server.com/register'
values = {'name' : 'Antonio Lezzi',
          'language' : 'Python' }

data = urllib.parse.urlencode(values)
print(data)
req = urllib.request.Request(url, data)
response = urllib.request.urlopen(req)
the_page = response.read()

import urllib.parse
import urllib.request

url = 'http://www.server.com/register'
values = {'name' : 'Antonio Lezzi',
          'language' : 'Python' }
user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
headers = { 'User-Agent' : user_agent }

data = urllib.parse.urlencode(values)
req = urllib.request.Request(url, data, headers)
response = urllib.request.urlopen(req)
the_page = response.read()

req = urllib.request.Request('http://www.pretend_server.org')
try:
    urllib.request.urlopen(req)
except urllib.error.URLError as e:
    print(e.reason)