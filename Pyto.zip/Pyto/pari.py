val = 0
while val < 20:
    if val % 2 == 0:
        print (str(val) + " è pari")
    val += 2
print("terminato")
