def palindroma(string):
    result = True
    str_len = len(string)
    for i in range(0, int(str_len/2)):
        if string[i] != string[str_len-i-1]:
            result = False
            break
    return result

def palindroma2(str):
    revstr = reversed(str)

    if list(str) == list(revstr):
        return True

    return False
def palindroma3(n):
    return (n == n[::-1])

def palindromaRic(string) :
    if len(string) <= 1 :
        return True
    if string[0] == string[len(string) - 1] :
        return palindromaRic(string[1:len(string) - 1])
    else :
        return False

parola = input("Inserisci una parola:")
res = palindroma(parola)

if res == True:
# check if the string is equal to its reverse
   print("La parola è palindroma")
else:
   print("La parola non è palindroma")
