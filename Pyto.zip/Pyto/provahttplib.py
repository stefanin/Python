import http.client
import json

class Service(object):
    conn = None
    
    def __init__(self):
        self.conn = http.client.HTTPConnection("letus.vfdns.org")
    
    def listLogFile(self):
        self.conn.request(method = "GET", url = "/java/teatro/teatro.json", headers = { "Content-Type": "application/json" })
        res = self.conn.getresponse()
        data = json.loads(res.read())
        #for i in data:
        #print (i["nome"])
        #print (i["eta"])
        print(data)
        
        self.conn.close()

        return data

    
try:
    s = Service()
    data = s.listLogFile()

    #for i in data:
    print (data["nometeatro"])
    print (data["email"])

except json.JSONDecodeError as jerr:
    print(jerr)