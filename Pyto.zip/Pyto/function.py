def stampaNome(nomeArg, confNome):
    if nomeArg == confNome:
        print("Questo è un bel nome")
    elif nomeArg == "Mario Rossi":
        print("sei un bel colore")
    elif nomeArg == "Giuseppe Verdi":
        print("sei un brutto colore")
    else:
        print("Tu hai un bel nome!")

def somma(op1, op2 = 5):
    return op1 + op2

def passMethod():
    pass

x = input("inserisci un nome ")
nomeConfronto = "Antonio Lezzi"
stampaNome(x, nomeConfronto)

val1 = int(input("inserisci un valore "))
val2 = int(input("inserisci un secondo valore "))

print("la somma è: " + str(somma(val1, val2)))
print("il 5 + val1: " + str(somma(val1)))


passMethod()