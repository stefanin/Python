def MostraAgenda(agenda):
    print("Agenda Telefonica:")
    for x in agenda.keys():
        print ("Nome: ",x," \tTelefono: ",agenda[x])

def AggiungiNumero(agenda,Nome,Telefono):
    agenda[Nome] = Telefono

def CercaNumero(agenda,Nome):
    if agenda.has_key(Nome):
        return "Numero Telefonico "+agenda[Nome]
    else:
        return Nome+" non trovato"

def CancellaNumero(agenda,Nome):
    if agenda.has_key(Nome):
        del agenda[Nome]
    else:
        print(Nome," non trovato")

def CaricaAgenda(agenda,NomeFile):
    in_file = open(NomeFile,"r")
    while 1:
        in_line = in_file.readline()
        if in_line == "":
            break
        in_line = in_line[:-1]
        [Nome,Telefono] = string.split(in_line,";")
        agenda[Nome] = Telefono
    in_file.close()

def SalvaAgenda(agenda,NomeFile):
    out_file = open(NomeFile,"w")
    for x in agenda.keys():
        out_file.write(x+";"+agenda[x]+"\n")    
    out_file.close()

def print_menu():
    print('----------- AGENDA -------------')
    print('1. Mostra Agenda')
    print('2. Aggiungi un nuovo numero')
    print('3. Cancella un numero telefonico')
    print('4. Cerca un numero telefonico')
    print('5. Carica Agenda')
    print('6. Salva Agenda')
    print('7. Esci')
    print('--------------------------------')

DizionarioNumeri = {}
SceltaMenu = 0
print_menu()

while SceltaMenu != 7:
    SceltaMenu = int(input("Menu (1-7):"))
    if SceltaMenu == 1:
        MostraAgenda(DizionarioNumeri)
    elif SceltaMenu == 2:
        print("Aggiungi un nome e il numero telefonico")
        Nome = input("Nome:")
        phone = input("Telefono:")
        AggiungiNumero(DizionarioNumeri,Nome,phone)
    elif SceltaMenu == 3:
        print("Rimuovi il Nome e il relativo telefono")
        Nome = input("Nome:")
        CancellaNumero(DizionarioNumeri,Nome)
    elif SceltaMenu == 4:
        print("Ricerca il numero telefonico")
        Nome = input("Nome:")
        print(CercaNumero(DizionarioNumeri,Nome))
    elif SceltaMenu == 5:
        NomeFile = input("Nome del file da caricare:")
        CaricaAgenda(DizionarioNumeri,NomeFile)
    elif SceltaMenu == 6:
        NomeFile = input("Nome del file da salvare:")
        SalvaAgenda(DizionarioNumeri,NomeFile)
    elif SceltaMenu == 7:
        pass
    else:
        print_menu()