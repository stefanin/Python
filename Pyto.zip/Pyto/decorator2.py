def mio_decoratore(funzione_da_decorare):
    def wrapper(*args, **kwargs):
        #Con gli argomenti possiamo fare ciò che vogliamo
        kwargs['foo'] = "argomento modificato"
        print("Stiamo chiamando la funzione %s con argomenti " \
            "%s e parole chiave %s" % (funzione_da_decorare.__name__, args, kwargs))
        return funzione_da_decorare(*args, **kwargs)

    return wrapper

@mio_decoratore
def molt(a, b, foo = "foo"):
    print(foo)
    return a * b

print(molt(1, 2))
