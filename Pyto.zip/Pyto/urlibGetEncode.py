import urllib.parse
import urllib.request

url = 'http://www.server.com/register'
values = {'name' : 'Antonio Lezzi',
          'language' : 'Python' }

data = urllib.parse.urlencode(values)
print(data)
#req = urllib.request.Request(url, data)
#response = urllib.request.urlopen(req)
#the_page = response.read()