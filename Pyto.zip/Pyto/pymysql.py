import PyMySQL

# Apertura di una connessine al DB
db = PyMySQL.connect("letus.vfdns.org","letus","","Gestionale" )

# creazione di un cursor
cursor = db.cursor()

# esecuzione della query SQL usando il metodo execute()
cursor.execute("SELECT * FROM Viaggi")

# Ottiene un singolo record usando il metodo fetchone()
data = cursor.fetchall()

print(data)

# chiusura connessione dal server
db.close()