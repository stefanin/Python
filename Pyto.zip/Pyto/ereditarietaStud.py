class persona:
    nome = ""
    cognome = ""
    eta = 0
    indirizzo = ""
    telefono = ""
    stato_civile = ""

    def __init__(self,n = None,c = None):
        self.nome = n
        self.cognome = c

    def setEta(self, value):
        assert(isinstance(value, int))
        assert(value>=0)
        self.eta = value
        return self

    def cambia_indirizzo(foo,s):
        foo.indirizzo = s

    def cambia_telefono(self,s):
        self.telefono = s

    def cambia_stato_civile(self,s):
        self.stato_civile = s

    def stampa(self):
        print(self.nome,self.cognome,self.eta,self.indirizzo,self.stato_civile)

    #@staticmethod
    def codice(nome, cognome):
        print(nome, cognome)


class studente (persona): # ecco l’ereditarietà!
    scuola = ""
    classe = 0

    def cambia_scuola(self,s):
        self.scuola = s

    def promosso(self):
        if self.classe == 5:
            print('scuola finita')
        else:
            self.classe = self.classe + 1

    def stampa(self):
        #print(self.nome,self.cognome,self.indirizzo,self.stato_civile)
        super().stampa()
        print("scuola: "+self.scuola+" classe "+str(self.classe))


p1 = persona("antonio", "lezzi") # le parentesi sono obbligatorie
p1.cambia_indirizzo('via milano n. 10') # richiamo un metodo
p1.stampa() # risultato : antonio lezzi via milano n. 10


s1 = studente("mario", "rossi")
s1.cambia_indirizzo("via pisa n. 10")
s1.cambia_scuola("liceo")
s1.stampa() # risultato : mario rossi via pisa n. 10