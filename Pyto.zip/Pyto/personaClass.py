class persona:
    __nome = ""
    __cognome = ""
    __eta = 0
    indirizzo = ""
    telefono = ""
    stato_civile = ""

    def __init__(self,n,c):
        self.__nome = n
        self.__cognome = c

    def setEta(self, value):
        assert(isinstance(value, int))
        assert(value>=0)
        self.__eta = value
        return self

    def cambia_indirizzo(foo,s):
        foo.indirizzo = s

    def cambia_telefono(self,s):
        self.telefono = s

    def cambia_stato_civile(self,s):
        self.stato_civile = s

    def stampa(self):
        print(self.__nome,self.__cognome,self.__eta,self.indirizzo,self.stato_civile)

    @staticmethod
    def codice(nome, cognome):
        print(nome, cognome)



pippo = persona("Pippo", "Pluto")
pippo.setEta(40)
pippo.cambia_indirizzo("via...")

antonio = persona("Antonio", "Lezzi")
antonio.setEta(35)

pippo.setEta(20)


print("Stampo i dati di Antonio")
antonio.stampa()
print("Stampo i dati di Pippo")
pippo.stampa()

#antonio.__nome = "Pippo %s %s" % (" Ciao", "pluto")
#print("Finto nome :", antonio.__nome)
#antonio.stampa()

#persona.stampa(antonio)

print("metodo statico")
persona.codice("AAA", "BBB")

#print(antonio)