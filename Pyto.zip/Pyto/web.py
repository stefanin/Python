from urllib.request import urlopen

for line in urlopen('http://www.python.org/community/diversity/'):
    text = line.decode('utf-8')
    if '<title>' in text:
        print(text)#<title>Diversity</title>
        
import webbrowser
url = 'http://www.python.org/dev/peps/pep-0001/'
webbrowser.open(url) # Apre un url usando il browser di default