def provaPassword(secret, tentativi):
    c = 0
    trovato = 0
    pwd = ''
    while c < tentativi:
        pwd = input("inserisci la parola ")
        if pwd == secret:
            trovato = 1
            break
        c += 1
    return trovato

res = provaPassword("passwords", 5)

if res == 1:
    print("parola trovata")
else:
    print("parola non trovata")
