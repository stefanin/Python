def mio_decoratore(funzione_da_decorare):
    #fai qualcosa con la funzione, per es.
    funzione_da_decorare.prova = "stringa di prova"
    return funzione_da_decorare

def molt(a, b):
    return a * b

molt = mio_decoratore(molt)

print("stampo molt senza decoratore", molt)
print("stampo molt.prova senza decoratore:", molt.prova)
print()

@mio_decoratore
def moltConDecorator(a, b):
    return a * b


print("stampo molt con decoratore", moltConDecorator)
print("stampo molt.prova con decoratore:", moltConDecorator.prova)