class A:
    def metodo1(self):
        print("Metodo 'metodo1' della classe A")
    def metodo2(self):
        print("Metodo 'metodo2' della classe A")
class B:
    def metodo1(self):
        print("Metodo 'metodo1' della classe B")
    def metodo2(self):
        print("Metodo 'metodo2' della classe B")
    def metodo3(self):
        print("Metodo 'metodo3' della classe B")
class C(A, B):
    def metodo1(self):
        print("Metodo 'metodo1' della classe C")

class D(B, A):
    def metodo1(self):
        super(B).me
        print("Metodo 'metodo1' della classe D")

objC = C()
objC.metodo1() #Metodo 'metodo1' della classe C
objC.metodo2() #Metodo 'metodo2' della classe A
objC.metodo3() #Metodo 'metodo3' della classe B

print()

objD = D()
objD.metodo1() #Metodo 'metodo1' della classe C
objD.metodo2() #Metodo 'metodo2' della classe A
objD.metodo3() #Metodo 'metodo3' della classe B