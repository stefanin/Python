import sqlite3 as sq
from classiTeatro import *

class Dat:
    __conn = None

    def __init__(self,dat):
        self.__conn = sq.connect(dat)

    def get(self, idTitle): 
        with self.__conn:
            cursor = self.__conn.cursor()
            cursor.execute("SELECT * FROM film where id = %d or title = '%s'" % (idTitle[0],idTitle[1]))
            rows = cursor.fetchall()
            return rows
        
    def stampa(self,idTitle):
        rows = self.get(idTitle)    
        for row in rows:
            print("%s - %s" % (row[0], row[1]))

    def getConn(self):
        return self.__conn


if __name__ == "__main__":
    ticketsDat = Dat('dat.sqlite')
    idTitle = (1,'django')
    ticketsDat.stampa(idTitle)
    ticket = Ticket(1,2,3)

    Ticket.add1(ticketsDat.getConn(), ticket)
    ticketsDat.stampa((4, 2))