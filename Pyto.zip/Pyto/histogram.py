def histogram(lista):
    for x in lista:
        for i in range(0, x):
            print("*", end="")
        print("")

histogram([5,2,6])