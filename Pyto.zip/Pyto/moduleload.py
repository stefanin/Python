import usefulmodule

if __name__ == '__main__':
    print("Ho importato un modulo che si chiama %s" % usefulmodule.__name__)
    print("Adesso richiamero' una funzione di quel modulo:")
    usefulmodule.usefulfunctions.show_sys_paths()