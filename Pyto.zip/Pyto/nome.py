nome = "Antonio Lezzi"
x = input("inserisci un nome ")

if x == nome:
    print("Questo è un bel nome")
elif x == "Mario Rossi":
    print("sei un bel colore")
elif x == "Giuseppe Verdi":
    print("sei un brutto colore")
else:
    print("Tu hai un bel nome!")
