class Ticket:
    __persona = None
    __spettacolo = None
    __data = None

    def __init__(self, p, s, d):
        self.__persona = p
        self.__spettacolo = s
        self.__data = ""

    def __str__(self):
        return "***Stampa Ticket ***\n%s %s %s" % (str(self.__persona), str(self.__spettacolo), self.__data)

    def getSpettacolo(self):
        return self.__spettacolo

class Persona:
    __nome = ""
    __cognome = ""

    def __init__(self, n, c):
        self.__nome = n
        self.__cognome = c

    def prova():
        print("AAAA")

    def __str__(self):
        return "Nominativo: %s %s" % (self.__nome, self.__cognome)

class Spettatore (Persona):
    __biglietti = []

    def acquistaTicket(self, ticket):
        self.__biglietti.append(ticket)

class Botteghino (Persona):
    __bigliettiVenduti = []

    def rilasciaTicket(self, persona, spettacolo):
        ticket = Ticket(persona, spettacolo, "16/01/2017")
        self.__bigliettiVenduti.append(ticket)
        return ticket

    def bigliettiVenduti(self):
        return self.__bigliettiVenduti

class Mascherina (Persona):
    def controlloAccesso(self, tickets, spettacoli):
        for s in spettacoli:
            print("\n*** Mascherina %s analizza Spettacolo: %s ***" % (str(self), str(s)))
            countPers = 0
            for t in tickets:
                if t.getSpettacolo() == s:
                    countPers = countPers + 1

            if 3 <= countPers <= 5:
                print("Avvio %s presenze: %d" % (str(s), countPers))
            else:
                print("Non avvio %s presenze: %d" % (str(s), countPers))
            

class Spettacolo:
    __nome = ""
    __costo = 0.0

    def __init__(self, n, c):
        self.__nome = n
        self.__costo = c

    def __str__(self):
        return "Titolo: %s Costo: %d" % (self.__nome, self.__costo)


if __name__ == "__main__":
    pers1 = Spettatore("Andrea", "Rossi")
    pers2 = Spettatore("Giuseppe", "Verdi")
    pers3 = Spettatore("Elisa", "Gialli")
    pers4 = Spettatore("Roberto", "Blue")

    spet1 = Spettacolo("Aida1", 10.5)
    spet2 = Spettacolo("Aida2", 20.5)

    spets = [spet1, spet2]

    bott1 = Botteghino("Alberto", "Soldini")
    masc1 = Mascherina("Arlecchino", "Pulcinella")

    tick1 = bott1.rilasciaTicket(pers1,spet1)
    pers1.acquistaTicket(tick1)
    print(tick1)
    tick2 = bott1.rilasciaTicket(pers2,spet1)
    pers2.acquistaTicket(tick2)
    print(tick2)
    tick3 = bott1.rilasciaTicket(pers3,spet1)
    pers3.acquistaTicket(tick1)
    print(tick3)
    tick4 = bott1.rilasciaTicket(pers4,spet2)
    pers4.acquistaTicket(tick4)
    print(tick4)

    ticks = bott1.bigliettiVenduti()
    masc1.controlloAccesso(ticks, spets)