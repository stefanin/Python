# Utilizzo delle funzioni ricorsive
# per il calcolo del fattoriale di un numero

def fattoriale(n):
    """Il fattoriale di un numero indica il prodotto di
        quel numero per tutti i suoi antecedenti"""
            
    if n == 1:
        return 1
    else:
        return (n * fattoriale(n-1))

res = int(input("Inserisci un numero: "))
if res >= 1:
    print("Il fattoriale di", res, "è", fattoriale(res))