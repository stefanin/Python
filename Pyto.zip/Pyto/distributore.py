class Bottiglia:
    contenuto = ""
    capacita = 0

    def __init__(self, c, n):
        self.contenuto = c
        self.capacita = n

    def __str__(self):
        return self.contenuto + " ha capacità " + str(self.capacita)

class Distributore:
    bevande = []

    def __init__(self, *b):
        self.bevande.extend(b)

    def __str__(self):
        strg = ""
        for b in self.bevande:
            strg = strg + str(b) + "\n"

        return strg

if __name__ == "__main__":
    b1 = Bottiglia("CocaCola", 0.5)
    b2 = Bottiglia("Fanta", 0.5)
    b3 = Bottiglia("Acqua", 0.5)

    d = Distributore(b1, b2, b3)

    print(b1)
    print(b2)

    print(d)
    