class Ticket:
    __persona = None
    __spettacolo = None
    __data = None

    def __init__(self, p, s, d):
        self.__persona = p
        self.__spettacolo = s
        self.__data = ""

    def __str__(self):
        return "***Stampa Ticket ***\n%s %s %s" % (str(self.__persona), str(self.__spettacolo), self.__data)

    def getSpettacolo(self):
        return self.__spettacolo

    #@classmethod
    def add1(cas,ticket):
        #print("AAAA")
        cursor = cas.cursor()
        cursor.execute("INSERT INTO film values (%d, '%s')" % (4,ticket.getSpettacolo()))
        cas.commit()
