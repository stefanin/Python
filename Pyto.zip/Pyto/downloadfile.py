import urllib.request
urllib.request.urlretrieve('http://letus.vfdns.org/java/teatro/teatro.json', 'file.txt')