#coding=utf-8

class Lampadina:
    stato = False

    def __init__(self, st = False):
        self.stato = st

    def accendi(self):
        self.stato = True

    def spegni(self):
        self.stato = False

    def impostaStato(self, st):
        self.stato = st

    def interruttore(self):
        self.stato = not(self.stato)

    def ottieniStato(self):
        return self.stato

def esempioTupla(*args):
    print(args)
    print(type(args))

if __name__ == "__main__":
    l1 = Lampadina()
    print("Lampadina l1 appena creata con stato", l1.ottieniStato())
    print("Lampadina l1 accesa")
    l1.accendi()
    print("Lampadina l1 visualizza stato dopo averla accesa", l1.ottieniStato())
    l1.spegni()    
    print("Lampadina l1 visualizza stato dopo averla spenta", l1.ottieniStato())
    l1.impostaStato(True)
    print("Lampadina l1 è stata accesa e risulta:", l1.ottieniStato())
    l1.interruttore()
    print("Lampadina l1 dopo aver premuto l'interruttore", l1.ottieniStato())

    l2 = Lampadina(True)
    print("Lampadina l2 appena creata con stato", l2.ottieniStato())

    n = int(input("Quante lampadine vuoi? "))

    scatola = []
    for i in range(n):
        scatola.append(Lampadina())

    for l in scatola:
        print("La lampadina è " + str(l.ottieniStato()))

    scelta = int(input("Quale lampadina vuoi accendere?"))
    if scelta >= 0 and scelta < len(scatola):
        scatola[scelta].accendi()

    for l in scatola:
        print("La lampadina è " + str(l.ottieniStato()))

    esempioTupla("Primo elemento", 1, True)