class Bottiglia:
    quantita = 0
    contenuto = ""
    capacita = 0

    def __init__(self, qt, ct):
        self.quantita = qt
        self.contenuto = ct
        self.capacita = self.quantita

    def bevi(self, qt):
        if qt <= self.quantita:
            self.quantita -= qt
        else:
            self.quantita = 0

    def riempi(self):
        if self.quantita == 0:
            self.quantita = self.capacita

    def __str__(self):
        return "tipo: " + self.contenuto + " qt:" + str(self.quantita) + " cp:" + str(self.capacita)
        
class Distributore:
    l = []

    def __init__(self, *d):
        self.l = list(d)

    def __str__(self):
        descr = ""

        for item in self.l:
            descr = descr + " " + str(item) + "\n"

        return descr

if __name__ == "__main__":
    b1 = Bottiglia(0.33, "CocaCola")
    b2 = Bottiglia(0.5, "Acqua")

    print("La prima stampa", b1)

    d = Distributore(b1, b2)
    d = Distributore(b1, b2)

    print("stampa delle bottiglie del distributore")
    print(d)