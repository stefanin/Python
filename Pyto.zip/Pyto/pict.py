class Picture():
    aaa = "aaa"

    def __init__(self, filename, width=320, height=240, filetype='JPEG'):
        self.filename = filename
        self.setWidth(width)
        self.setHeight(height)
        self.filetype=filetype

    def setWidth(self, value):
       self.__width = value

    def setHeight(self, value):
       self.__height = value

    def setAaa(self, b):
        self.aaa = b

img1=Picture('gatto.jpg', height=480)

img1.setWidth(200)
img1.__width = -10 # crea un nuovo attributo, non fa accedere a quello privato

print("Visualizzazione dell'intero dizionario:")
print(img1.__dict__)
print("La stampa di una variabile di istanza definita dentro la classe fuori dai metodi senza self", img1.aaa)
img1.setAaa("ccc")
print("nuova stamp", img1.aaa)
