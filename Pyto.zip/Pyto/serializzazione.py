import pickle

class Foo():
    def __init__(self, name):
        self.name = name
    def __str__(self):
        return 'Foo «%s»' % self.name


data=('foo', 'bar', 'baz')

f = open('mydata', 'wb')
pickle.dump(data, f, pickle.HIGHEST_PROTOCOL)
f.close()

data=()

f = open('mydata', 'rb')
data = pickle.load(f)
f.close()

print(data) #('foo', 'bar', 'baz')

data1 = (
        Foo('abc'), Foo('def'), Foo('ghi'),
        ['uno', 'due', 'tre'],
        {'a': 'primo', 'b': 'secondo', 'c': 'terzo'}
        )

f = open('mydata1', 'wb')
pickle.dump(data1, f, pickle.HIGHEST_PROTOCOL)
f.close()

f = open('mydata1', 'rb')
data2 = pickle.load(f)
f.close()

print(data2)
print(data2[0].name)