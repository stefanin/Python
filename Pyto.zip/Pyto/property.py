class Fruit(object):
    name = None

    def __init__(self, n):
        self.name = n

    @property
    def quality(self):
        return self.__quality
    
    @quality.setter
    def quality(self, value):
        if 0 <= value <= 100:
            self.__quality = value
        else:
            self.__quality = 50

if __name__ == "__main__":
    myapple = Fruit('mela granny smith')
    myapple.quality = 10
    print('1 quality %d' % myapple.quality)
    myapple.quality = -20
    print('2 quality %d' % myapple.quality)
