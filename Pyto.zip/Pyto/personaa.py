class personaa:
    __nome = ""
    __cognome = ""
    
    def __init__(self, nome, cognome = ""):
        self.__nome = nome
        self.__cognome = cognome

    def impostaNome(self, nome):
        self.__nome = nome

    def stampa(self):
        self.__cf = "LZZNNG"
        print(self.__nome, self.__cognome, self.__cf)
        
p1 = personaa("Antonio", "Lezzi")
p1.__nome = "Pippo"
p1.__cognome = "AAAA"
p1.eta = 40
p1.stampa()
print("Cambiamo nome")
p1.impostaNome("Pluto")
p1.stampa()
print("Stampa fuori dalla classe " + p1.__nome + " " + p1.__cognome)


p2 = personaa("Maria", "Bianchi")
p2.stampa()